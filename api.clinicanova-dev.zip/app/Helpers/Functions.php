<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Helpers;

use DateTime;

/**
 * Description of newPHPClass
 *
 * @author ander
 */
class Functions {

    public static function dateBrToDB($date) {

        return implode('-', array_reverse(explode('/', $date)));
    }

    public static function dateDbToBr($date) {
        return implode('/', array_reverse(explode('-', $date)));
    }

    public static function cpfToNumber($cpf) {
        return str_replace('-', '', str_replace('.', '', $cpf));
    }

    public static function cepToNumber($cpf) {
        return str_replace('-', '', str_replace('.', '', $cpf));
    }

    public static function datetimeToTuotempo($data) {
        $dateF = Functions::dateDbToBr(substr($data, 0, 10));
        $dateF = $dateF . ' ' . substr($data, 11, 8);
        return $dateF;
    }

    public static function dateTuotempoToDB($data) {
        $dateF = Functions::dateBrToDB(substr($data, 0, 10));
        $dateF = $dateF . ' ' . substr($data, 11, 8);
        return $dateF;
    }

    public static function sexoToSigla($sexo) {

        $array = array('Masculino' => 'M', 'Feminino' => 'F');
        if (!empty($sexo)) {
            return $array[$sexo];
        } else {
            return null;
        }
    }

    public static function siglaSexoToNome($sexo) {

        $array = array('M' => 'Masculino', 'F' => 'Feminino');
        if (!empty($sexo)) {
            return $array[$sexo];
        } else {
            return null;
        }
    }

    /**
     * 
     * @param type $valorParcial
     * @param type $valorTotal
     */
    public static function calculaPorcertagemParcial($valorParcial, $valorTotal) {
        $percentual = ($valorParcial * 100) / $valorTotal;
        return $percentual;
    }

    /**
     * 
     * @param type $dataNascimento
     */
    public static function calculaIdade($dataNascimento) {
        $dtIni = new DateTime($dataNascimento);
        $dtAtual = new DateTime(date('Y-m-d H:i:s'));
        $diff = $dtAtual->diff($dtIni);
        return $diff->y;
    }

    public static function utf8Fix($msg, $utf8ToAccents = true) {
        $accents = array("á", "à", "â", "ã", "ä", "é", "è", "ê", "ë", "í", "ì", "î", "ï", "ó", "ò", "ô", "õ", "ö", "ú", "ù", "û", "ü", "ç", "Á", "À", "Â", "Ã", "Ä", "É", "È", "Ê", "Ë", "Í", "Ì", "Î", "Ï", "Ó", "Ò", "Ô", "Õ", "Ö", "Ú", "Ù", "Û", "Ü", "Ç", "º", "ª");
        $utf8 = array("Ã¡", "Ã ", "Ã¢", "Ã£", "Ã¤", "Ã©", "Ã¨", "Ãª", "Ã«", "Ã­", "Ã¬", "Ã®", "Ã¯", "Ã³", "Ã²", "Ã´", "Ãµ", "Ã¶", "Ãº", "Ã¹", "Ã»", "Ã¼", "Ã§", "Ã", "Ã€", "Ã‚", "Ãƒ", "Ã„", "Ã‰", "Ãˆ", "ÃŠ", "Ã‹", "Ã", "ÃŒ", "ÃŽ", "Ã", "Ã“", "Ã’", "Ã”", "Ã•", "Ã–", "Ãš", "Ã™", "Ã›", "Ãœ", "Ã‡", "Âº", "Âª");
        if ($utf8ToAccents) {
            $fix = str_replace($utf8, $accents, $msg);
        } else {
            $fix = str_replace($accents, $utf8, $msg);
        }

        return $fix;
    }

    public static function calcularDescontoPercentual($valorProc, $tipo, $valorTipoDesconto) {
        $retorno = ($valorProc * ($valorTipoDesconto / 100));
        return $retorno;
    }

    public static function validateDate($date) {

        $date = explode('-', $date);

        if (count($date) != 3) {
            return false;
        }
        return checkdate($date[1], $date[2], $date[0]);
    }

    public static function gerarHorarios($inicio, $termino, $intervalo) {

        $HoraInicio = explode(':', $inicio);
        $HoraTermino = explode(':', $termino);

        $inicio = mktime($HoraInicio[0], $HoraInicio[1], 0);
        $termino = mktime($HoraTermino[0], $HoraTermino[1], 0, date('m'), date('d'), date('Y'));
        $intervalo = $intervalo * 60;

        $cont = 0;
        $horarioAnt = $inicio;
        $HORARIOS[] = date('H:i', $inicio);
        while ($inicio <= $termino) {
            $cont++;
            $horario = $horarioAnt + $intervalo;

            if ($horario > $termino) {

                break;
            }

            $HORARIOS[] = date('H:i', $horario);
            $horarioAnt = $horario;

            if ($cont == 200) {
                break;
                exit;
            }
        }

        return $HORARIOS;
    }

    public static function array_sort($array, $on, $order = SORT_ASC) {
        $new_array = array();
        $sortable_array = array();

        if (count($array) > 0) {
            foreach ($array as $k => $v) {
                if (is_array($v)) {
                    foreach ($v as $k2 => $v2) {
                        if ($k2 == $on) {
                            $sortable_array[$k] = $v2;
                        }
                    }
                } else {
                    $sortable_array[$k] = $v;
                }
            }

            switch ($order) {
                case SORT_ASC:
                    asort($sortable_array);
                    break;
                case SORT_DESC:
                    arsort($sortable_array);
                    break;
            }

            foreach ($sortable_array as $k => $v) {
                $new_array[$k] = $array[$k];
            }
        }

        return $new_array;
    }

    /**
     * 
     * @param type $tipo 1 - SOmente cósigo, 2 Código/Ano
     * @param type $anoCod 
     * @param type $codigo
     * @return string
     */
    public static function codFinanceiroRecDesp($tipo, $anoCod, $codigo) {

        if (empty($anoCod) and empty($codigo)) {
            return '';
        }

        if ($tipo == 1) {
            return $codigo;
        } elseif ($tipo == 2) {
            return $codigo . '/' . $anoCod;
        }
    }

    /**
     * 
     * @param type $tipo 1 - SOmente cósigo, 2 Código/Ano
     * @param type $anoCod 
     * @param type $codigo
     * @return string
     */
    public static function statusConsultas() {

        return [
            'jaSeEncontra',
            'estaSendoAtendido',
            'jaFoiAtendido',
            'faltou',
            'desmarcado',
        ];
    }

    public static function qntProcedimentosDocBizz($procNome, $qnt, $convenioId, $totalRegitros) {

        $retorno['consulta'] = 0;
        $retorno['procedimento'] = 0;
        if (strpos('consulta', strtolower($procNome)) !== false
                and ( $convenioId == 41 OR ( $totalRegitros == 1 and $convenioId != 41))
        ) {
            $retorno['consulta'] = $qnt;
        } else if (strpos('consulta', strtolower($procNome)) === false) {
            $retorno['procedimento'] = $qnt;
        }

        return $retorno;
    }

    public static function correcaoUTF8Decode($texto) {
        if (mb_detect_encoding($texto) == 'UTF-8') {
            $texto = Functions::utf8Fix($texto);
        } else {
            $texto = utf8_decode($texto);
        }
        return $texto;
    }

}
