<?php

namespace App\Http\Controllers\ApiClinicas;

use App\Http\Controllers\ApiClinicas\Controller;
use App\Services\Clinicas\AgendaService;
use Illuminate\Http\Request;
use App\Services\Clinicas\AtendimentoService;
use App\Services\Clinicas\ConsultaService;
use App\Services\Clinicas\HorariosService;

class ConsultaController extends Controller {

    private $agendaService;
    private $atendimentoService;
    private $consultaService;
    private $horarioService;

    public function __construct(AgendaService $agServ, AtendimentoService $atendSErv, ConsultaService $consServ, HorariosService $horServ) {
        $this->agendaService = $agServ;
        $this->atendimentoService = $atendSErv;
        $this->consultaService = $consServ;
        $this->horarioService = $horServ;
    }

    public function index(Request $request) {
        $getDominio = $this->getIdDominio($request, 'input', true);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }



        $result = $this->consultaService->getAll($idDominio, $request);
        return $this->returnResponse($result);
    }

    public function getById(Request $request, $consultaId) {


        $getDominio = $this->getIdDominio($request, 'input', true);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }
        
        $dadosFiltro['showProcedimentos'] = false;
        $dadosFiltro['showProntuarios'] = false;
        $showProntuarios = false;
        if ($request->has('showProcedimentos') and $request->query('showProcedimentos') == 'true') {
            $dadosFiltro['showProcedimentos'] = true;
        }
        if ($request->has('showProntuarios') and $request->query('showProntuarios') == 'true') {
            $dadosFiltro['showProntuarios'] = true;
        }

        $result = $this->consultaService->getById($idDominio, $consultaId, $dadosFiltro);
        return $this->returnResponse($result);
    }

    public function store(Request $request) {


        $getDominio = $this->getIdDominio($request, 'input', true);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }

        $validator = validator($request->input(), [
            'doutorId' => 'required|numeric',
            'pacienteId' => 'required|numeric',
            'data' => 'required|date_format:Y-m-d',
            'horario' => 'required|date_format:H:i',
        ]);
        if ($validator->fails()) {
            return $this->sendErrorValidator($validator->errors()->all());
        } else {


            $result = $this->consultaService->store($idDominio, $request->input());
            return $result;
        }
    }

}
