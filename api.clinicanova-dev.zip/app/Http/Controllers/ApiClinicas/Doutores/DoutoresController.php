<?php

namespace App\Http\Controllers\ApiClinicas\Doutores;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiClinicas\Controller as BaseController;
use App\Services\Clinicas\Doutores\DoutoresService;

class DoutoresController extends BaseController {

    private $doutoresService;

    public function __construct(DoutoresService $pacArquivoServ) {
        $this->doutoresService = $pacArquivoServ;
    }

    public function index(Request $request) {

        $getDominio = $this->getIdDominio($request, 'input', false);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }



        $dadosFiltro = null;

//        $validate = $this->validate($request->query(),
//                [
//                    'nome'=>'alpha',
//                    'valorConsulta'=>'numeric',
//                    'valorConsultaMax'=>'numeric',
//                ],[
//                   'nome.alpha'=> 'O campo nome deve conter somente letras',
//                   'nome.valorConsulta'=> 'O valorConsulta dever numérico',
//                   'nome.valorConsultaMax'=> 'O valorConsultaMax dever numérico',
//                    
//                ]);
//        
        if ($request->has('sexo') and ! empty($request->query('sexo')) and ( $request->query('sexo') != 'M' and $request->query('sexo') != 'F' and $request->query('sexo') != 'O')) {
            return $this->sendErrorValidator('Tipo de sexo inválido');
        }
        if ($request->has('tipoAtendimento') and ! empty($request->query('tipoAtendimento')) and (
                $request->query('tipoAtendimento') != 'presencial' and $request->query('tipoAtendimento') != 'video' and $request->query('tipoAtendimento') != 'presencial,video')) {
            return $this->sendErrorValidator('Tipo de atendimento inválido');
        }

        if ($request->has('grupoAtendimentoId')) {
            foreach ($request->query('grupoAtendimentoId') as $chave => $idGrupAtend) {
                if (!empty($idGrupAtend) and ! is_numeric($idGrupAtend)) {
                    return $this->sendErrorValidator('Grupo de atendimento [' . $chave . '] inválido');
                }
            }
        }

        if ($request->has('idiomaId')) {
            foreach ($request->query('idiomaId') as $chave => $idGrupAtend) {
                if (!empty($idGrupAtend) and ! is_numeric($idGrupAtend)) {
                    return $this->sendErrorValidator('Id do idioma [' . $chave . '] inválido');
                }
            }
        }
        $result = $this->doutoresService->getAll($idDominio, $request->query());
        return $result;
    }

    public function store(Request $request, $pacienteId) {

        $getDominio = $this->getIdDominio($request, 'input', true);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }


        $result = $this->doutoresService->store($idDominio, $pacienteId, $request);
        return $this->returnResponse($result);
    }

    public function delete(Request $request, $pacienteId) {

        $getDominio = $this->getIdDominio($request, 'input', true);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }
        $result = $this->doutoresService->delete($idDominio, $pacienteId, $arquivoId);

        return $result;
    }

    public function update(Request $request, $pacienteId, $arquivoId) {

        $getDominio = $this->getIdDominio($request, 'input', true);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }


        $result = $this->doutoresService->update($idDominio, $pacienteId, $arquivoId, $request->input('title'));

        return $result;
    }

    public function storeAvaliacoes(Request $request, $doutorId) {

        $getDominio = $this->getIdDominio($request, 'input', true);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }


        $validation = validator($request->input(), ['pacienteId' => 'required|numeric',
            'pontuacao' => 'required|numeric|min:0|max:5',
                ], [
            'pacienteId.required' => 'Infome o ID do paciente',
            'pacienteId.numeric' => 'O id do paciente deve ser numérico',
            'pontuacao.required' => 'Infome a pontuação',
            'pontuacao.numeric' => 'A pontuação deve ser numérico',
            'pontuacao.min' => 'A pontuação deve ser no mínimo 0 e no máximo 5',
            'pontuacao.max' => 'A pontuação deve ser no mínimo 0 e no máximo 5',
                ]
        );

        if ($validation->fails()) {
            return $this->sendErrorValidator($validation->errors()->all());
        } else {

            $result = $this->doutoresService->storeAvaliacoes($idDominio, $doutorId, $request->input('pacienteId'), $request->input('pontuacao'));
        }



        return $result;
    }

}
