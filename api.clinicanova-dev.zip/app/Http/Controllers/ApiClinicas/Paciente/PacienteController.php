<?php

namespace App\Http\Controllers\ApiClinicas\Paciente;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiClinicas\Controller as BaseController;
use App\Services\Clinicas\PacienteService;
use Illuminate\Validation\Rules\Password;

class PacienteController extends BaseController {

    private $pacienteService;

    public function __construct(PacienteService $pacFotoServ) {
        $this->pacienteService = $pacFotoServ;
    }

//    public function index(Request $request, $pacienteId) {
//
//
//        $result = $this->pacienteService->getAll($this->getIdDominio(), $pacienteId, $request);
//        return $this->returnResponse($result);
//    }

    public function store(Request $request) {

        $validate = validator($request->input(), [
            'nome' => 'required|min:3|max:255',
            'sobrenome' => 'required|min:3|max:255',
            'email' => 'email',
            'senha' => 'min:8|max:16',
                ]
        );

        if ($validate->fails()) {
            return $this->sendErrorValidator($validate->errors()->all());
        } else {

            $result = $this->pacienteService->store($this->getIdDominio(), $pacienteId, $request->input());
            return $this->returnResponse($result);
        }
    }

    public function index(Request $request) {


        $getDominio = $this->getIdDominio($request, 'input', false);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }
        $dadosFiltro = null;
        $page = 1;
        $perPage = 100;
        if ($request->has('page') and ! empty($request->query("page"))) {
            $page = $request->query("page");
        }
        if ($request->has('perPage') and ! empty($request->query("perPage"))) {
            $perPage = $request->query("perPage");
        }
        if ($request->has('search') and ! empty($request->query("search"))) {
            $dadosFiltro['search'] = $request->query("search");
        }


        $result = $this->pacienteService->getAll($idDominio, $dadosFiltro, $page, $perPage);
        return $this->returnResponse($result);
    }

    public function login(Request $request) {


        $getDominio = $this->getIdDominio($request, 'input', false);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }

        $validate = validator($request->input(), [
            'email' => 'required_without:authTokenBio|email',
            'senha' => 'required_without:authTokenBio|min:8|max:16',
                ]
        );

        $tokenBio = null;
        if ($request->has('authTokenBio') and ! empty($request->input('authTokenBio'))) {
            $tokenBio = $request->input('authTokenBio');
        } else {
            
        }

        if ($validate->fails()) {
            return $this->sendErrorValidator($validate->errors()->all());
        } else {
            $result = $this->pacienteService->login($idDominio, $request->input('email'), $request->input('senha'), $tokenBio);
            return $this->returnResponse($result);
        }
    }

    public function esqueciSenha(Request $request) {

        $getDominio = $this->getIdDominio($request, 'input', false);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }

        app('translator')->setLocale('pt-br');


        $validate = validator($request->input(), ['email' => 'required|email',
            'codigo' => 'numeric|digits:6',
            'password' => ['required_with:codigo', 'min:8', 'max:14', Password::min(8)->mixedCase()->numbers()->symbols(),],
            'confirmPassword' => 'required_with:password|same:password',
                ], [
            'email.required' => 'Informe o e-mail',
            'email.email' => 'E-mail inválido',
            'codigo.numeric' => 'O código deve ser numérico',
            'codigo.digits' => 'O código deve ter 6 digitos',
            'password.required' => "Informe a nova senha",
            'password.min' => "A nova senha dever ter no mínimo 8 caracteres",
            'confirmPassword.required_with' => "Confirme a nova senha",
            'confirmPassword.same' => "As novas senhas são diferentes",
                ]
        );


        if ($validate->fails()) {
            return $this->sendErrorValidator($validate->errors()->all());
        } else {

            if ($request->has('codigo') and ! empty($request->input('codigo'))) {
                return $result = $this->pacienteService->esqueciSenhaVerificaCodigo($idDominio, $request->input('email'), $request->input('codigo'), $request->input('password'));
            } else {

                return $result = $this->pacienteService->esqueciSenha($idDominio, $request->input('email'));
            }
        }
    }

    public function alterarSenha(Request $request, $pacienteId) {


        $getDominio = $this->getIdDominio($request, 'input', false);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }


        app('translator')->setLocale('pt-br');

        $validate = validator($request->input(), [
            'oldPassword' => ['required'],
            'newPassword' => ['required', 'min:8', 'max:14', Password::min(8)->mixedCase()->numbers()->symbols(),],
            'confirmNewPassword' => 'required|same:newPassword',
                ], [
            'oldPassword.required' => "Informe a senha atual",
            'newPassword.required' => "Informe a nova senha",
            'newPassword.min' => "A nova senha dever ter no mínimo 8 caracteres",
            'newPassword.mixedCase' => "A nova senha dever ter no mínimo 8 caracteres",
            'confirmNewPassword.required' => "Confirme a nova senha",
            'confirmNewPassword.same' => "As novas senhas são diferentes",
                ], ['validation.min.string']);


        if ($validate->fails()) {
            return $this->sendError(
                            ['success' => false,
                                'data' => null,
                                'message' => $validate->errors()->all()[0]
            ]);
        } else {

            $result = $this->pacienteService->alterarSenha($idDominio, $pacienteId, $request->input('newPassword'), true, $request->input('oldPassword'));

            return $result;
        }
    }

    public function googleRegistrar(Request $request) {


        $getDominio = $this->getIdDominio($request, 'input', true);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }

        $validate = validator($request->input(), [
            'nome' => 'required',
            'sobrenome' => 'required',
            'email' => 'required',
            'codigoGoogle' => 'required',
            'urlFotoGoogle' => 'required',
            'perfilId' => 'required',
                ], [
            'nome.required' => 'Informe o nome do paciente',
            'sobrenome.required' => 'Informe o sobrenome do paciente',
            'email.required' => 'Informe o email do paciente',
            'codigoGoogle.required' => 'Informe o código do Google',
            'urlFotoGoogle.required' => 'Informe a url da foto no Google',
            'perfilId.required' => 'Informe o id  do perfil',
        ]);

        if ($validate->fails()) {
            return $this->sendError(
                            ['success' => false,
                                'data' => null,
                                'message' => $validate->errors()->all()[0]
            ]);
        } else {

            $result = $this->pacienteService->googleRegistro($idDominio, $request->input());
            return $result;
        }
    }

    public function googleLogin(Request $request) {

        $getDominio = $this->getIdDominio($request, 'input', true);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }

        $validate = validator($request->input(), [
            'codigoGoogle' => 'required',
            'perfilId' => 'required',
                ], [
            'codigoGoogle.required' => 'Informe o código do Google',
            'perfilId.required' => 'Informe o id  do perfil',
        ]);

        if ($validate->fails()) {
            return $this->sendError(
                            ['success' => false,
                                'data' => null,
                                'message' => $validate->errors()->all()[0]
            ]);
        } else {

            $result = $this->pacienteService->googleLogin($idDominio, $request->input('codigoGoogle'));

            return $result;
        }
    }

    public function facebookRegistrar(Request $request) {


        $getDominio = $this->getIdDominio($request, 'input', true);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }

        $validate = validator($request->input(), [
            'nome' => 'required',
            'sobrenome' => 'required',
            'email' => 'required',
            'codigoFacebook' => 'required',
            'urlFotoFacebook' => 'required',
            'perfilId' => 'required',
                ], [
            'nome.required' => 'Informe o nome do paciente',
            'sobrenome.required' => 'Informe o sobrenome do paciente',
            'email.required' => 'Informe o email do paciente',
            'codigoFacebook.required' => 'Informe o código do Facebook',
            'urlFotoFacebook.required' => 'Informe a url da foto no Facebook',
            'perfilId.required' => 'Informe o id  do perfil',
        ]);

        if ($validate->fails()) {
            return $this->sendError(
                            ['success' => false,
                                'data' => null,
                                'message' => $validate->errors()->all()[0]
            ]);
        } else {

            $result = $this->pacienteService->facebookRegistro($idDominio, $request->input());
      
            return $result;
        }
    }

    public function facebookLogin(Request $request) {

        $getDominio = $this->getIdDominio($request, 'input', true);
        if ($getDominio['success']) {
            $idDominio = $getDominio['perfisId'];
        } else {
            return response()->json($getDominio);
        }

        $validate = validator($request->input(), [
            'codigoFacebook' => 'required',
            'perfilId' => 'required',
                ], [
            'codigoFacebook.required' => 'Informe o código do Facebook',
            'perfilId.required' => 'Informe o id  do perfil',
        ]);

        if ($validate->fails()) {
            return $this->sendError(
                            ['success' => false,
                                'data' => null,
                                'message' => $validate->errors()->all()[0]
            ]);
        } else {

            $result = $this->pacienteService->facebookLogin($idDominio, $request->input('codigoFacebook'));

            return $result;
        }
    }

//    public function delete(Request $request, $pacienteId, $fotoId) {
//
//        if (empty($fotoId)) {
//            return $this->sendError('Informe o id da foto');
//        }
//
//
//
//        $result = $this->pacienteService->delete($this->getIdDominio(), $pacienteId, $fotoId);
//
//        return $result;
//    }
//
//    public function update(Request $request, $pacienteId, $fotoId) {
//
//        if (empty($fotoId)) {
//            return $this->sendError('Informe o id da foto');
//        }
//
//
//        if (!$request->has('title') or empty($request->input('title'))) {
//            return $this->sendError('Informe o nome da foto');
//        }
//
//        $result = $this->pacienteService->update($this->getIdDominio(), $pacienteId, $fotoId, $request->input('title'));
//
//        return $result;
//    }
}
