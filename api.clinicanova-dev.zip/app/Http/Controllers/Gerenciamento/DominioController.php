<?php

namespace App\Http\Controllers\Gerenciamento;

use App\Http\Controllers\ApiClinicas\Controller;
use Illuminate\Http\Request;


class DominioController extends Controller {

    private $agendaService;


}
