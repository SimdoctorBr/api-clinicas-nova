<?php

namespace App\Repositories\Clinicas;

use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\DB;

class CompromissoRepository extends BaseRepository {

    public function getAll($idDominio, $idDoutor, $dadosFiltro = null) {

        $sqlData = '';
        if (isset($dadosFiltro['data']) and ! empty($dadosFiltro['data'])) {

            if (isset($dadosFiltro['dataFim']) and ! empty($dadosFiltro['dataFim'])) {
                $sqlData = " AND  A.data_compromisso >='{$dadosFiltro['data']}' AND A.data_compromisso <= '{$dadosFiltro['dataFim']}' ";
            } else {
                $sqlData = "AND A.data_compromisso = '{$dadosFiltro['data']}'";
            }
        }
      
        $qr = $this->connClinicas()->select("SELECT A.*      FROM	compromissos as A
                                         WHERE 
                                        identificador = $idDominio AND A.doutores_id = '$idDoutor' 
                                             $sqlData
                                        ORDER BY hora_agendamento");
     
        return $qr;
    }

}
