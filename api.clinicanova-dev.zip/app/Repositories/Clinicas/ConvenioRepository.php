<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Repositories\Clinicas;

use App\Repositories\BaseRepository;

/**
 * Description of ConvenioRepository
 *
 * @author ander
 */
class ConvenioRepository extends BaseRepository {

    public function getAll($idDominio) {

        if (is_array($idDominio)) {
            $sql = 'A.identificador IN(' . implode(',', $idDominio) . ")";
        } else {
            $sql = "A.identificador = $idDominio";
        }

        $qr = $this->connClinicas()->select("SELECT *, A.id as convenios_id,
            (CONVERT(CAST(CONVERT(   A.nome USING latin1) AS BINARY) USING UTF8))           as nomeConvenio FROM convenios as A WHERE  A.`status` = 1 AND  ($sql OR A.id = 41)");
        return $qr;
    }

    public function getById($idDominio, $idConvenio) {

        if (is_array($idDominio)) {
            $sql = 'A.identificador IN(' . implode(',', $idDominio) . ")";
        } else {
            $sql = "A.identificador = $idDominio";
        }

        $qr = $this->connClinicas()->select("SELECT *, A.id as convenios_id,   (CONVERT(CAST(CONVERT(   A.nome USING latin1) AS BINARY) USING UTF8)) as nomeConvenio FROM convenios as A WHERE  A.`status` = 1 AND $sql AND A.id =$idConvenio");
        return $qr;
    }

    public function getConveniosPacientes($idDominio, $idPaciente, $doutorId = null) {

        if (!empty($doutorId)) {
            $sql = "AND A.doutores_id = $doutorId";
        }
        $qr = $this->connClinicas()->select("SELECT A.*,  (CONVERT(CAST(CONVERT(   B.nome USING latin1) AS BINARY) USING UTF8))AS nomeConvenio,AES_DECRYPT(C.nome_cript, '$this->ENC_CODE') as nomeDoutor
                                    FROM convenios_pacientes AS A
                                    LEFT JOIN convenios AS B ON A.convenios_id = B.id
                                    INNER JOIN doutores as C
                                    ON C.id = A.doutores_id
                                    WHERE A.identificador = '$idDominio' AND pacientes_id = '$idPaciente' AND A.status = 1
                                        AND C.status_doutor = 1
                                        $sql
                                        ;");
        return $qr;
    }

    public function verificaExisteConveniosPacientes($identificador, $id_doutor, $pacientes_id, $convenios_id = null) {
        $sql = '';
        if (!empty($convenios_id)) {
            $sql = " AND convenios_id = $convenios_id";
        }

        $qr = $this->connClinicas()->select("SELECT * FROM convenios_pacientes WHERE identificador = $identificador AND doutores_id = $id_doutor AND  pacientes_id = $pacientes_id $sql");
        return $qr;
    }

    /**
     * 
     * @param type $identificador
     * @param array $dadosConveniosPac
     *  dados:
     * $campos['identificador'] 
      $campos['pacientes_id']
      $campos['numero_carteira']
      $campos['validade_carteira']
      $campos['convenios_id']
      $campos['doutores_id']
      $campos['status'] = 1;
     * 
     * @return type
     */
    public function conveniosPacientesInsert($idDominio, Array $dadosConveniosPac) {


        $qrIsExist = $this->verificaExisteConveniosPacientes($idDominio, $dadosConveniosPac['doutores_id'], $dadosConveniosPac['pacientes_id']);
        if (count($qrIsExist) == 0) {


            $campos['identificador'] = $idDominio;
            $campos['pacientes_id'] = $dadosConveniosPac['pacientes_id'];
            $campos['numero_carteira'] = $dadosConveniosPac['numero_carteira'];
            $campos['validade_carteira'] = (!empty($dadosConveniosPac['validade_carteira'])) ? $dadosConveniosPac['validade_carteira'] : null;
            $campos['convenios_id'] = $dadosConveniosPac['convenios_id'];
            $campos['doutores_id'] = $dadosConveniosPac['doutores_id'];

            return $this->insertDB('convenios_pacientes', $campos, null, 'clinicas');
        } else {
            $campos['numero_carteira'] = $dadosConveniosPac['numero_carteira'];
            $campos['status'] = 1;
            $this->updateDB('convenios_pacientes', $campos, " identificador = $idDominio AND id =  {$qrIsExist[0]->id} LIMIT 1", null, 'clinicas');
            return $qrIsExist[0]->id;
        }
    }

    /**
     * Convenios que o doutor aceita
     * 
     * @param type $identificador
     * @param type $idDoutor
     */
    public function getAllConveniosDoutores($idDominio, $idDoutor) {

        $qrCat = $this->connClinicas()->select("SELECT A.*, (CONVERT(CAST(CONVERT(   B.nome USING latin1) AS BINARY) USING UTF8)) as nomeConvenio, C.nome as nomeTipoCodigo FROM convenios_doutores as A
                                INNER JOIN convenios as B
                                ON A.convenios_id = B.id
                                LEFT JOIN convenios_tipo_codigo_operadora as C
                                ON C.id = A.convenios_tipo_codigo_operadora_id
                                 WHERE A.identificador = '$idDominio' AND doutores_id = '$idDoutor' AND A.status = 1;");
        return $qrCat;
    }

}
