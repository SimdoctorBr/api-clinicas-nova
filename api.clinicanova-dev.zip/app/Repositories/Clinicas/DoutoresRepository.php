<?php

namespace App\Repositories\Clinicas;

use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\DB;

class DoutoresRepository extends BaseRepository {

    public function getAll($idDominio, $dadosFiltro = null, $page = null, $perPage = null) {

        if (is_array($idDominio)) {
            $sql = 'A.identificador IN(' . implode(',', $idDominio) . ")";
        } else {
            $sql = "A.identificador = $idDominio";
        }



        $sqlFiltro = '';
        $sqlFiltroCampos = '';
//        if (isset($dadosFiltro['doutoresId'])) {
//            $sqlFiltro .= " AND  A.doutores_id = '" . $dadosFiltro['doutoresId'] . "'";
//        }
//        dd($dadosFiltro); 
        if (isset($dadosFiltro['nome']) and ! empty($dadosFiltro['nome'])) {
            $sqlFiltro .= " AND  (CAST(AES_DECRYPT(nome_cript, '$this->ENC_CODE') AS CHAR(255)) like '%{$dadosFiltro['nome']}%' OR 
                CONVERT( BINARY   AES_DECRYPT(nome_cript, '$this->ENC_CODE')  USING latin1) LIKE '%{$dadosFiltro['nome']}%')";
        }
        if (isset($dadosFiltro['valorConsulta']) and ! empty($dadosFiltro['valorConsulta'])) {

            if (isset($dadosFiltro['valorConsultaMax']) and ! empty($dadosFiltro['valorConsultaMax'])) {
                $sqlFiltro .= " AND  (CAST( REPLACE(A.preco_consulta,',','.') AS DECIMAL(11,2)) >= '{$dadosFiltro['valorConsulta']}' AND
              CAST( REPLACE(A.preco_consulta,',','.') AS DECIMAL(11,2)) <= '{$dadosFiltro['valorConsultaMax']}')";
            } else {
                $sqlFiltro .= " AND  (CAST( REPLACE(A.preco_consulta,',','.') AS DECIMAL(11,2)) >= '{$dadosFiltro['valorConsulta']}')";
            }
        }

        if (isset($dadosFiltro['sexo']) and ! empty($dadosFiltro['sexo'])) {
            $sqlFiltro .= " AND  sexo = '{$dadosFiltro['sexo']}'";
        }

        if (isset($dadosFiltro['tipoAtendimento']) and ! empty($dadosFiltro['tipoAtendimento'])) {

            if (count(explode(',', $dadosFiltro['tipoAtendimento'])) < 2) {
                if ($dadosFiltro['tipoAtendimento'] == 'presencial') {
                    $sqlFiltro .= " AND (A.possui_videoconf =0 OR (A.possui_videoconf = 1 AND  A.somente_videoconf=0))";
                } else if ($dadosFiltro['tipoAtendimento'] == 'video') {
                    $sqlFiltro .= " AND  A.possui_videoconf =1 ";
                }
            }
        }



        if (isset($dadosFiltro['especialidade']) and ! empty($dadosFiltro['especialidade'])) {

            if (is_array($idDominio)) {
                $sqlDominioEsp = 'doutores_especialidades.identificador IN(' . implode(',', $idDominio) . ")";
            } else {
                $sqlDominioEsp = "doutores_especialidades.identificador = $idDominio";
            }
            $sqlFiltro .= " AND (

                            SELECT COUNT(*) FROM doutores_especialidades 
                            INNER JOIN especialidades
                            ON especialidades.id = doutores_especialidades.especialidade_id
                            WHERE  $sqlDominioEsp AND especialidades.nome = '" . utf8_encode($dadosFiltro['especialidade']) . "'
                            AND doutores_especialidades.doutores_id = A.id
                            ) >0
                            ";
        }

        if (isset($dadosFiltro['grupoAtendimentoId']) and count(array_filter($dadosFiltro['grupoAtendimentoId'])) > 0) {


            $idsGrupoAtend = implode(',', array_filter($dadosFiltro['grupoAtendimentoId']));

            $sqlFiltro .= " AND (SELECT COUNT(*)
                                    FROM doutores_grupo_atendimento
                                    WHERE identificador = A.identificador AND doutores_id = A.id  AND grupo_atendimento_id IN({$idsGrupoAtend}) AND status = 1
                            ) >0
                            ";
        }

        if (isset($dadosFiltro['idiomaId']) and count(array_filter($dadosFiltro['idiomaId'])) > 0) {


            $idiomaId = implode(',', array_filter($dadosFiltro['idiomaId']));

            $sqlFiltro .= " AND (SELECT COUNT(*) FROM doutores_idiomas  WHERE
                                                identificador = A.identificador AND doutores_id = A.id AND idiomas_id IN($idiomaId) AND STATUS = 1
                            ) >0
                            ";
        }

        if (isset($dadosFiltro['nomeFormacao']) and count(array_filter($dadosFiltro['nomeFormacao'])) > 0) {

            $nomesFormacao = array_filter($dadosFiltro['nomeFormacao']);
            $nomesFormacao = array_map(function($item) {
                return "'" . $item . "'";
            }, $nomesFormacao);
            $nomesFormacao = implode(',', $nomesFormacao);

            $sqlFiltro .= " AND (SELECT COUNT(*) FROM doutores_formacoes WHERE
                                               identificador = A.identificador AND nome_formacao IN($nomesFormacao)  AND doutores_id = A.id
                            ) >0
                            ";
        }
        
        if (isset($dadosFiltro['favoritoPacienteId']) and  !empty($dadosFiltro['favoritoPacienteId'])) {
             $sqlFiltroCampos .= ", (SELECT COUNT(*) FROM pacientes_doutores_favoritos WHERE
                                               identificador = A.identificador AND doutores_id = A.id AND pacientes_id = ".$dadosFiltro['favoritoPacienteId']." 
                            ) as favoritoPaciente
                            ";
        }
        
        
        if (isset($dadosFiltro['totalConsultasAtendidas']) and $dadosFiltro['totalConsultasAtendidas'] == true) {

            $sqlFiltroCampos .= ",
                (SELECT COUNT(*)
     FROM consultas 
    WHERE consultas.doutores_id = A.id AND consultas.identificador = A.identificador
    AND (SELECT STATUS FROM consultas_status WHERE consulta_id =consultas.id ORDER BY id DESC LIMIT 1) = 'jaFoiAtendido') as totalConsultasAtendidas";
        }

        $orderBy = "ORDER BY A.nome ASC";
        if (isset($dadosFiltro['orderBy']) and ! empty($dadosFiltro['orderBy'])) {
            $orderBy = " ORDER BY {$dadosFiltro['orderBy']} ";
        }


        $camposSQL = "A.id,A.sobre,A.sexo,A.especialidades_id,A.identificador,A.preco_consulta,A.website,A.mensagem_antes_marcar,A.pronome_id,A.cor,A.cor_letra,A.conselho_profissional_id,
            A.conselho_uf_id,A.cbo_s_id,A.nome_foto,A.data_cad as dataCad,A.administrador_id_cad,A.possui_repasse,A.tipo_repasse,A.valor_repasse,A.possui_videoconf,A.permite_agenda_website,A.doutor_parceiro,A.nome_responsavel,
            A.status_doutor,A.somente_videoconf, A.plano_aluguel_sala_id,A.tags_tratamentos,A.pontuacao,
            AES_DECRYPT(nome_cript, '$this->ENC_CODE') as nome,
                                AES_DECRYPT(email_cript, '$this->ENC_CODE') as email,
                                AES_DECRYPT(telefone_cript, '$this->ENC_CODE') as telefone,
                                AES_DECRYPT(celular1_cript, '$this->ENC_CODE') as celular1,
                                AES_DECRYPT(celular2_cript, '$this->ENC_CODE') as celular2,
                                AES_DECRYPT(cpf_cript, '$this->ENC_CODE') as cpf,
                                AES_DECRYPT(cnpj_cript, '$this->ENC_CODE') as cnpj,
                                AES_DECRYPT(cns_cript, '$this->ENC_CODE') as cns,
                                AES_DECRYPT(banco1_cript, '$this->ENC_CODE') as banco1,
                                AES_DECRYPT(conta1_cript, '$this->ENC_CODE') as conta1,
                                AES_DECRYPT(agencia1_cript, '$this->ENC_CODE') as agencia1,
                                AES_DECRYPT(banco2_cript, '$this->ENC_CODE') as banco2,
                                AES_DECRYPT(conta2_cript, '$this->ENC_CODE') as conta2,
                                AES_DECRYPT(agencia2_cript, '$this->ENC_CODE') as agencia2,
                                B.abreviacao, B.nome as nomePronome,B.artigo, D.nome as nomeConselhoProfissional, D.codigo as codigoConselhoProfisssional,
                                                E.ds_uf_nome as nomeUFConselhoProfisional, E.ds_uf_sigla as siglaUFConselhoProfisional, F.codigo as codigoCBO, F.nome as nomeCBO,
                                                   AES_DECRYPT(conselho_profissional_numero_cript, '$this->ENC_CODE') as conselho_profissional_numero,G.nome as nomePlanoSala $sqlFiltroCampos";
        $from = " 
            FROM doutores AS A 
             LEFT JOIN pronomes_tratamento as B
            ON A.pronome_id = B.idPronome
            LEFT JOIN tiss_conselhos_profisionais as D
            ON D.id = A.conselho_profissional_id
            LEFT JOIN uf as E
            ON E.cd_uf = A.conselho_uf_id
            LEFT JOIN tiss_cbo_s as F
            ON F.id =  A.cbo_s_id
            LEFT JOIN plano_aluguel_salas as G
            ON (G.id =  A.plano_aluguel_sala_id AND G.status = 1)
            WHERE  $sql AND A.status_doutor = 1 $sqlFiltro   $orderBy  ";

//        if (auth('clinicas')->user()->id = 4055) {
//        var_dump("SELECT $camposSQL $from");
//            exit;
//        }


        if ($page == null and $perPage == null) {
            $qr = $this->connClinicas()->select("SELECT $camposSQL $from");
            return $qr;
        } else {
            $qr = $this->paginacao($camposSQL, $from, 'clinicas', $page, $perPage, false);
            return $qr;
        }
    }

    public function getById($idDominio, $idDoutor) {

        if (is_array($idDominio)) {
            $sql = 'A.identificador IN(' . implode(',', $idDominio) . ")";
        } else {
            $sql = "A.identificador = $idDominio";
        }


        $qr = $this->connClinicas()->select("SELECT A.id,A.sobre,A.sexo,A.especialidades_id,A.identificador,A.preco_consulta,A.website,A.mensagem_antes_marcar,A.pronome_id,A.cor,A.cor_letra,A.conselho_profissional_id,
            A.conselho_uf_id,A.cbo_s_id,A.nome_foto,A.data_cad as dataCad,A.administrador_id_cad,A.possui_repasse,A.tipo_repasse,A.valor_repasse,A.possui_videoconf,A.permite_agenda_website,A.doutor_parceiro,A.nome_responsavel,
            A.status_doutor,A.somente_videoconf, A.plano_aluguel_sala_id,A.tags_tratamentos,A.pontuacao,
            AES_DECRYPT(nome_cript, '$this->ENC_CODE') as nome,
                                AES_DECRYPT(email_cript, '$this->ENC_CODE') as email,
                                AES_DECRYPT(telefone_cript, '$this->ENC_CODE') as telefone,
                                AES_DECRYPT(celular1_cript, '$this->ENC_CODE') as celular1,
                                AES_DECRYPT(celular2_cript, '$this->ENC_CODE') as celular2,
                                AES_DECRYPT(cpf_cript, '$this->ENC_CODE') as cpf,
                                AES_DECRYPT(cnpj_cript, '$this->ENC_CODE') as cnpj, 
                                AES_DECRYPT(cns_cript, '$this->ENC_CODE') as cns, B.abreviacao, B.nome as nomePronome,B.artigo, D.nome as nomeConselhoProfissional, D.codigo as codigoConselhoProfisssional,
                                E.ds_uf_nome as nomeUFConselhoProfisional, E.ds_uf_sigla as siglaUFConselhoProfisional, F.codigo as codigoCBO, F.nome as nomeCBO,
                                   AES_DECRYPT(conselho_profissional_numero_cript, '$this->ENC_CODE') as conselho_profissional_numero
                                    FROM doutores as A 
                                LEFT JOIN pronomes_tratamento as B
                                ON A.pronome_id = B.idPronome
                                LEFT JOIN tiss_conselhos_profisionais as D
                                           ON D.id = A.conselho_profissional_id
                                           LEFT JOIN uf as E
                                           ON E.cd_uf = A.conselho_uf_id
                                           LEFT JOIN tiss_cbo_s as F
                                           ON F.id =  A.cbo_s_id                                    

                                    WHERE $sql AND A.id = $idDoutor");
        if (count($qr) > 0) {
            return $qr[0];
        } else {
            return false;
        }
    }

}
