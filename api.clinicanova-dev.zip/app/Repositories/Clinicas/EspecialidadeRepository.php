<?php

namespace App\Repositories\Clinicas;

use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\DB;

class EspecialidadeRepository extends BaseRepository {

    public function getAll($idDominio, $dadosFiltro = null, $page = null, $perPage = null) {

        if (is_array($idDominio)) {
            $sqlDominio = 'identificador IN(' . implode(',', $idDominio) . ")";
        } else {
            $sqlDominio = "identificador = $idDominio";
        }
        

        $sqlFiltro = '';


        $orderBy = "ORDER BY    nome ASC";
        if (isset($dadosFiltro['orderBy']) and ! empty($dadosFiltro['orderBy'])) {
            $orderBy = " ORDER BY {$dadosFiltro['orderBy']} ";
        }

        if (isset($dadosFiltro['withDoctors']) and $dadosFiltro['withDoctors'] == true) {

            $camposSQL = "A.*, if(A.outro IS NOT NULL, A.outro, B.nome) AS nome,AES_DECRYPT(C.nome_cript, '$this->ENC_CODE')  AS nomeDoutor
 ";
            $from = " FROM doutores_especialidades AS A
            LEFT JOIN especialidades AS B
            ON A.especialidade_id = B.id
            LEFT JOIN doutores AS C
            ON C.id = A.doutores_id
            WHERE
            A.$sqlDominio
              ";
            $from .= (!empty($sqlFiltro)) ? " WHERE $sqlFiltro" : '';
            $from .= $orderBy;
        } else {
            $camposSQL = "*";
            $from = " 
            FROM (SELECT A.nome
                    FROM especialidades AS A
                    WHERE $sqlDominio                     
                    UNION
                    SELECT outro AS nome FROM doutores_especialidades WHERE
                    $sqlDominio AND outro IS NOT NULL) as q1
              ";
            $from .= (!empty($sqlFiltro)) ? " WHERE $sqlFiltro" : '';
            $from .= $orderBy;
        }




//
//
//        if (auth('clinicas_pacientes')->user()->id = 89375) {
//            var_dump("SELECT $camposSQL $from");
//            exit;
//        }
//        if ($page == null and $perPage == null) {
        $qr = $this->connClinicas()->select("SELECT $camposSQL $from");
        return $qr;
//        } else {
//            $qr = $this->paginacao($camposSQL, $from, 'clinicas', $page, $perPage, false);
//            return $qr;
//        }
    }

    public function getByDoutorId($idDominio, $doutores_id) {

        if (is_array($idDominio)) {
            $sqlDominio = 'A.identificador IN(' . implode(',', $idDominio) . ")";
        } else {
            $sqlDominio = "A.identificador = $idDominio";
        }
        
        $qr = $this->connClinicas()->select("SELECT *, if(outro IS NOT NULL, outro, B.nome) AS nome 
            FROM doutores_especialidades AS A
            LEFT JOIN especialidades AS B
            ON A.especialidade_id = B.id
            WHERE $sqlDominio AND doutores_id = $doutores_id");
        return $qr;
    }

}
