<?php

namespace App\Repositories\Clinicas;

use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\DB;

class StatusRefreshRepository extends BaseRepository {

    public function insertAgenda($idDominio, $doutorId) {

        $campos['doutores_id'] = $doutorId;
        $campos['agenda'] = 1;
        $campos['agenda_time'] = time();
        $campos['identificador'] = $idDominio;

        $qrVerifica = $this->connClinicas()->select("SELECT id FROM status_refresh WHERE identificador = '$idDominio' AND agenda = 1 AND doutores_id = '$doutorId'");

        if (count($qrVerifica) == 0) {
            return $this->insertDB('status_refresh', $campos, null, 'clinicas');
        } else {
            $row = $qrVerifica[0];
            
            $this->updateDB('status_refresh', $campos, "id = '$row->id' LIMIT 1", null, 'clinicas');
        }
    }

}
