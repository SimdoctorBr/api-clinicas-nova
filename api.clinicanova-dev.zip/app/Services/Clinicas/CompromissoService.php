<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Services\Clinicas;

use App\Services\BaseService;
use DateTime;
use App\Services\Clinicas\CalculosService;
use App\Repositories\Clinicas\CompromissoRepository;
use App\Helpers\Functions;

/**
 * Description of Activities
 *
 * @author ander
 */
class CompromissoService extends BaseService {

    private function responseFields($row) {
        $retorno['id'] = $row->id;
        $retorno['nome'] = $row->nome;
        $retorno['impedeConsultas'] = $row->impedeConsultas;
        $retorno['data'] = $row->data_compromisso;
        $retorno['hora'] = $row->hora_agendamento;
        $retorno['horaFim'] = $row->hora_fim;

        return $retorno;
    }

    /**
     * 
     * @param type $idDominio
     * @param type $idDoutor
     * @param type $dadosFiltro
     * @param type $tipoRetorno 1- Normal, 2 - Por data/hora
     * @return type
     */
    public function getAll($idDominio, $idDoutor, $dadosFiltro = null, $tipoRetorno = 1) {



        $CompromissoRepository = new CompromissoRepository;
        $qrCompromisso = $CompromissoRepository->getAll($idDominio, $idDoutor, $dadosFiltro);



        $COMPROMISSOS = null;
        if ($tipoRetorno == 1) {

            if (count($qrCompromisso) > 0) {
                foreach ($qrCompromisso as $row) {
                    $COMPROMISSOS[] = $this->responseFields($row);
                }
            }
        } elseif ($tipoRetorno == 2) {

            $i = 0;
            $horarioAnt = null;

            if (count($qrCompromisso) > 0) {

                foreach ($qrCompromisso as $row) {

                    $horario = substr($row->hora_agendamento, 0, 5);

                    if ($horario != $horarioAnt) {
                        $i = 0;
                    }

                    $COMPROMISSOS[$row->data_compromisso][$horario][$i] = $row;

                    $horarioAnt = $horario;
                    $i++;
                }
            }
        }
        return $COMPROMISSOS;
    }

 
}
