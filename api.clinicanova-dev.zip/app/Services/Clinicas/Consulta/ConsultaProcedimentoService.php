<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Services\Clinicas\Consulta;

use App\Services\BaseService;
use DateTime;
use App\Services\Clinicas\CalculosService;
use App\Repositories\Clinicas\Consulta\ConsultaProcedimentoRepository;
use App\Repositories\Clinicas\CarteiraVirtualRepository;
use App\Helpers\Functions;

/**
 * Description of Activities
 *
 * @author ander
 */
class ConsultaProcedimentoService extends BaseService {

    public function store($idDominio, $dadosInsert) {

        $campos['identificador'] = $idDominio;
        $campos['data_cad'] = date('Y-m-d H:i:s');
        $campos['valor_repasse'] = ( isset($dadosInsert['valor_repasse']) and ! empty($dadosInsert['valor_repasse'])) ? $dadosInsert['valor_repasse'] : null;
        $campos['tipo_repasse'] = (isset($dadosInsert['tipo_repasse']) and ! empty($dadosInsert['tipo_repasse'])) ? $dadosInsert['tipo_repasse'] : null;
        $campos['origem_repasse'] = (isset($dadosInsert['origem_repasse']) and ! empty($dadosInsert['origem_repasse'])) ? $dadosInsert['origem_repasse'] : null;
        $campos['executante_doutores_id'] = (isset($dadosInsert['executante_doutores_id']) and ! empty($dadosInsert['executante_doutores_id'])) ? $dadosInsert['executante_doutores_id'] : null;
        $campos['retorno_proc'] = (isset($dadosInsert['retorno_proc']) and ! empty($dadosInsert['retorno_proc'])) ? $dadosInsert['retorno_proc'] : null;
        $campos['dicom'] = (!empty($dadosInsert['dicom'])) ? $dadosInsert['dicom'] : null;
        $campos['dicom_code'] = (!empty($dadosInsert['dicom_code'])) ? $dadosInsert['dicom_code'] : null;
        $campos['dicom_modality_id'] = (!empty($dadosInsert['dicom_modality_id'])) ? $dadosInsert['dicom_modality_id'] : null;
        $campos['carteira_virtual_id_lanc'] = (!empty($dadosInsert['carteira_virtual_id_lanc'])) ? $dadosInsert['carteira_virtual_id_lanc'] : null;
        $campos['lancado_doutor_id'] = (!empty($dadosInsert['lancado_doutor_id'])) ? $dadosInsert['lancado_doutor_id'] : null;

        if (isset($dadosInsert['tipo_repasse']) and $dadosInsert['tipo_repasse'] == 1) {
            $campos['percentual_proc_repasse'] = $dadosInsert['percentual_proc_repasse'];
        }


        if (isset($dadosInsert['pag_parcial']) and $dadosInsert['pag_parcial'] == 1) {
            $campos['pag_parcial'] = ($dadosInsert['pag_parcial'] == 1) ? $dadosInsert['pag_parcial'] : null;
            $campos['financeiro_recebimentos_id'] = (count($dadosInsert['financeiro_recebimentos_id']) == 0) ? null : implode(',', $dadosInsert['financeiro_recebimentos_id']);
        }

        $campos['id_proc_pacote'] = (!empty($dadosInsert['id_proc_pacote'])) ? $dadosInsert['id_proc_pacote'] : null;
        $campos['id_proc_pacote_item'] = (!empty($dadosInsert['id_proc_pacote_item'])) ? $dadosInsert['id_proc_pacote_item'] : null;

        if (isset($dadosInsert['id_proc_pacote_item']) and ! empty($dadosInsert['id_proc_pacote_item'])) {
            $campos['base_calc_pacote_item'] = $dadosInsert['valor_proc'];
            $campos['valor_proc'] = null;
        }

        if (isset($dadosInsert['duracao']) and ! empty($dadosInsert['duracao'])) {
            $campos['duracao'] = $dadosInsert['duracao'];
        } else {
            $campos['duracao'] = null;
        }

        $campos['executante_nome_cript'] = (!empty($dadosInsert['executante_nome_cript'])) ? $dadosInsert['executante_nome_cript'] : null;



        if (isset($dadosInsert['idCarteriaVirtualItem']) and ! empty($dadosInsert['idCarteriaVirtualItem'])) {
            $CarteiraVirtualRepository = new CarteiraVirtualRepository();
            $CarteiraVirtualRepository->vinculaCarteiraItemConsulta($idDominio, $dadosInsert['idCarteriaVirtualItem'], $dadosInsert['consultas_id']);
        }

        $ConsultaProcedimentoRepository = new ConsultaProcedimentoRepository;
        if (isset($dadosInsert['id']) and ! empty($dadosInsert['id'])) {
            $ConsultaProcedimentoRepository->update($idDominio, $dadosInsert['id'], $dadosInsert);
            return $dadosInsert['id'];
        } else {

            return $ConsultaProcedimentoRepository->store($idDominio, $dadosInsert);
        }
    }

    public function getByConsultaId($idDominio, $consultaId, Array $idsConsultaProcedimentos = null) {
        $ConsultaProcedimentoRepository = new ConsultaProcedimentoRepository;

        $qrProcedimentos = $ConsultaProcedimentoRepository->getByConsultaId($idDominio, $consultaId,$idsConsultaProcedimentos);
        $retorno = null;

      
        
        iF (count($qrProcedimentos) > 0) {
            foreach ($qrProcedimentos as $rowProc) {
                $retorno[] = [
                    'id' => $rowProc->id,
                    'procedimentoId' => $rowProc->procedimentos_id,
                    'procConvId' => $rowProc->procedimentos_id.'_'.$rowProc->convenios_id,
                    'nome' => Functions::utf8Fix($rowProc->nome_proc),
                    'convenioId' => $rowProc->convenios_id,
                   'convenioNome' => Functions::correcaoUTF8Decode($rowProc->nome_convenio) ,
                    'valor' => $rowProc->valor_proc,
                    'qnt' => $rowProc->qnt,
                    'nomeCategoria' => $rowProc->procedimentos_cat_nome,
                    'pagParcial' => $rowProc->pag_parcial,
                    'idCarteiraItem' => $rowProc->id_carteira_item,
                    'financeiroRecebimentosId' => $rowProc->financeiro_recebimentos_id,
                    'codCarteiraVirtual' => $rowProc->codCarteiraVirtual,
                    'nomePacote' => $rowProc->nome_pacote,
                     'exibeAppNeofor' => ($rowProc->exibir_app_docbizz ==1)?true:false
                ];
            }
        }
        return $retorno;
    }

    public function excluir($idDominio, $consultaProcedimentoId, $consultaId = null) {
        $ConsultaProcedimentoRepository = new ConsultaProcedimentoRepository;
        $qrProcedimentos = $ConsultaProcedimentoRepository->excluir($idDominio, $consultaProcedimentoId, $consultaId);

        if ($qrProcedimentos) {
            return $this->returnSuccess('', 'Excluído com sucesso.');
        } else {
            return $this->returnError(null, 'Ocorreu um erro ao excluir o procedimento');
        }
    }

}
