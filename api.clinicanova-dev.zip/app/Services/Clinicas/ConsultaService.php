<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Services\Clinicas;

use App\Services\BaseService;
use DateTime;
use App\Services\Clinicas\CalculosService;
use App\Services\Clinicas\Paciente\ProntuarioService;
use App\Repositories\Clinicas\AgendaRepository;
use App\Repositories\Clinicas\AgendaFilaEsperaRepository;
use App\Repositories\Clinicas\DefinicaoMarcacaoConsultaRepository;
use App\Repositories\Clinicas\DefinicaoMarcacaoGlobalRepository;
use App\Repositories\Clinicas\DefinicaoHorarioRepository;
use App\Repositories\Clinicas\ConsultaRepository;
use App\Repositories\Clinicas\ConsultaStatusRepository;
use App\Repositories\Clinicas\StatusRefreshRepository;
use App\Services\Clinicas\Consulta\ConsultaProcedimentoService;
use App\Helpers\Functions;
use App\Repositories\Clinicas\DiasHorariosBloqueadosRepository;
use App\Services\Clinicas\Doutores\DoutoresService;
use App\Services\Clinicas\PacienteService;
use App\Services\Clinicas\HorariosService;
use App\Services\Gerenciamento\DominioService;
use App\Services\PagSeguroApi\PagSeguroItensAPI;
use App\Services\PagSeguroApi\PagSeguroApiService;
use App\Repositories\Clinicas\PagSeguroConfigRepository;
use App\Services\Clinicas\Emails\EmailAgendamentoService;
use App\Services\Clinicas\Consulta\ConsultaReservadaService;

/**
 * Description of Activities
 *
 * @author ander
 */
class ConsultaService extends BaseService {

    private $consultaRepository;
    private $definicaoMarcacaoConsultaRepository;
    private $prontuarioService;
    private $consultaProcedimentoService;

    public function __construct() {
        $this->consultaRepository = new ConsultaRepository;
        $this->definicaoMarcacaoConsultaRepository = new DefinicaoMarcacaoConsultaRepository;
        $this->prontuarioService = new ProntuarioService;
        $this->consultaProcedimentoService = new ConsultaProcedimentoService;
    }

    private function responseFields($rowConsulta, $nomeDominio, $showProcedimentos = false, $showProntuario = false) {



        $dataNascimento = (!empty($rowConsulta->dataNascPaciente)) ? Functions::dateBrToDB($rowConsulta->dataNascPaciente) : null;

        $idade = (!empty($dataNascimento) and Functions::validateDate($dataNascimento)) ? (int) Functions::calculaIdade($dataNascimento) : null;


        $rowUltimaConsulta = $this->consultaRepository->getUltimaConsultaPaciente($rowConsulta->identificador, $rowConsulta->doutores_id, $rowConsulta->pacientes_id, $rowConsulta->id);

        $retorno = array(
            'id' => $rowConsulta->id,
            'paciente' => [
                'id' => $rowConsulta->pacientes_id,
                'nomePaciente' => $rowConsulta->nomePaciente,
                'sobrenomePaciente' => $rowConsulta->sobrenomePaciente,
//                'cartaoNacionalSaude' => $rowConsulta->cartao_nacional_saude,
                'telefonePaciente' => trim(str_replace('(', '', str_replace(')', '', str_replace(' ', '', str_replace('-', '', $rowConsulta->telefonePaciente))))),
                'celularPaciente' => trim(str_replace('(', '', str_replace(')', '', str_replace(' ', '', str_replace('-', '', $rowConsulta->celularPaciente))))),
                'dataNascPaciente' => $dataNascimento,
                'idade' => $idade,
                'sexoPaciente' => $rowConsulta->sexoPaciente,
//                'nomePacienteCompleto' => $rowConsulta->nomePacienteCompleto,
//                'marcadoPor' => $rowConsulta->marcadoPor,
//                'emailPaciente' => $rowConsulta->emailPaciente,
//                'numeroCarteira' => $rowConsulta->numero_carteira,
//                'validadeCarteira' => $rowConsulta->validade_carteira,
//                'cpfPaciente' => $rowConsulta->cpfPaciente,
//                'nomeTipoSanguineo' => $rowConsulta->nomeTipoSanguineo,
//                'nomeFatorRh' => $rowConsulta->nomeFatorRh,
            ],
            'doutor' => [
                'id' => $rowConsulta->doutores_id,
                'nomeDoutor' => $rowConsulta->nomeDoutor,
//                'nomeConselhoProfissional' => $rowConsulta->nomeConselhoProfissional,
//                'conselhoProfissionalNumero' => $rowConsulta->conselho_profissional_numero,
//                'conselhoUfId' => $rowConsulta->conselho_uf_id,
//                'conselhoUfSigla' => $rowConsulta->siglaUfConselho,
//                'codigoCbo' => $rowConsulta->codigoCbo,
//                'cboId' => $rowConsulta->cbo_s_id,
//                'siglaConselhoProfissional' => $rowConsulta->siglaConselhoProfissional,
//                'conselhoProfissionalId' => $rowConsulta->conselho_profissional_id,
            ],
            'convenio' => ['id' => $rowConsulta->convenios_id,
                'nome' =>    Functions::correcaoUTF8Decode($rowConsulta->nomeConvenio) ]
            ,
            'mensagem' => $rowConsulta->mensagem,
            'pacientesSemCadastroId' => $rowConsulta->pacientes_sem_cadastro_id,
            'confirmacao' => $rowConsulta->confirmacao,
//            'emailProximidadeEnviado' => $rowConsulta->email_de_proximidade,
//            'emailProximidadeEnviado2' => $rowConsulta->email_de_proximidade2,
//            'smsProximidadeEnviado' => $rowConsulta->sms_de_proximidade,
//            'smsProximidadeEnviado2' => $rowConsulta->sms_de_proximidade2,
//            'smsProximidadeEnviado2' => $rowConsulta->sms_de_proximidade2,
//                'dataAgendamento' => $rowConsulta->data_agendamento,
//                'mostraHistorico' => $rowConsulta->mostra_historico,
//                'emailsEnviados' => $rowConsulta->emails_enviados,
//                'smsEnviados' => $rowConsulta->sms_enviados,
            'observacoes' => $rowConsulta->dados_consulta,
//                'numero_tiss' => $rowConsulta->numero_tiss,
            'dataConsulta' => $rowConsulta->data_consulta,
            'horaConsulta' => $rowConsulta->hora_consulta,
            'horaConsultaFim' => $rowConsulta->hora_consulta_fim,
            'valorRecebido' => $rowConsulta->valor_recebido,
            'valorTroco ' => $rowConsulta->valor_troco,
            'encaixe' => $rowConsulta->encaixe,
            'encaixeObservacao' => $rowConsulta->encaixe_observacao,
            'encaixeAutorizadoPor' => $rowConsulta->encaixe_observacao,
        );

        if ($rowUltimaConsulta) {
            $retorno['paciente']['ultimaConsulta']['data'] = $rowUltimaConsulta->data_consulta;
            $retorno['paciente']['ultimaConsulta']['hora'] = $rowUltimaConsulta->hora_consulta;
        }
       
        if (!empty($rowConsulta->statusConsulta)) {

            $statusDados = explode('_', $rowConsulta->statusConsulta);
            $retorno['statusConsulta'] = $statusDados[0];
            $retorno['horaStatus'] = (!empty($statusDados[1]))? date('Y-m-d H:i:s', $statusDados[1]):'' ;
        } else {
            $retorno['statusConsulta'] = null;
            $retorno['horaStatus'] = null;
        }

        $retorno['videoconferencia'] = ['status' => false, 'codigo' => null, 'link' => null];

        if ($rowConsulta->videoconferencia == 1) {
            $retorno['videoconferencia'] = [
                'status' => true,
                'codigo' => $rowConsulta->codigo_id_videoconf,
                'videoPago' => $rowConsulta->video_conf_pago,
                'link' => $this->getLinkVideo($rowConsulta->codigo_id_videoconf, $nomeDominio),
            ];
        }

        $retorno['pagSeguro'] = [
            'status' => false,
            'codigoRefPag' => null,
            'link' => null,
            'validadeLink' => null
        ];
        if (!empty($rowConsulta->link_pagseguro)) {
            $retorno['pagSeguro'] = [
                'status' => true,
                'codigoRefPag' => $rowConsulta->cod_ref_pagseguro,
                'link' => $rowConsulta->link_pagseguro,
                'validadeLink' => $rowConsulta->pagseguro_validade_link
            ];
        }

        $retorno['pago'] = false;
        if (!empty($rowConsulta->idRecebimento)) {
            $retorno['pago'] = true;
        }

        //pag_seguro_status
        //pag_seg_transaction_id
        //pagseguro_validade_link
        //pag_seguro_status
        //cod_ref_pagseguro
        //link_pagseguro
        //cod_pagseguro
        //lista procedimentos
        if ($showProcedimentos) {

            $retorno['procedimentos'] = null;
            $qrProcedimentos = $this->consultaProcedimentoService->getByConsultaId($rowConsulta->identificador, $rowConsulta->id);
//                        dd($qrProcedimentos);
            $retorno['procedimentos'] = $qrProcedimentos;
        }

        //listar prontuarios
        if ($showProntuario) {

            $retorno['prontuarios'] = null;
            $qrProntuario = $this->prontuarioService->getByConsultaId($rowConsulta->identificador, $rowConsulta->id);
            $retorno['prontuarios'] = $qrProntuario;
        }




        return $retorno;
    }

    private function validateStatusConsulta($statusConsulta) {

        $listStatusConsultas = Functions::statusConsultas();

        if (!is_array($statusConsulta)) {
            $statusConsulta = explode(',', $statusConsulta);
        }


        foreach ($statusConsulta as $status) {
            if (!in_array($status, $listStatusConsultas)) {
                return false;
            }
        }
        return true;
    }

    private function getLinkVideo($CodVideo, $nomeDominio) {
        return env('APP_URL_CLINICAS') . '/' . $nomeDominio . '/videoconf?c=' . $CodVideo;
    }

    public function getAll($idDominio, $request) {

        $validate = validator($request->query(), [
            'doutorId' => 'numeric',
            'data' => 'date',
            'dataFim' => 'date',
            'horaInicio' => 'date_format:H:i',
            'horaFim' => 'date_format:H:i',
                ], [
            'doutorId.required' => 'Doutor(a) não informado',
            'doutorId.numeric' => 'Doutor(a) não informado',
            'data.required' => 'Data não informada',
            'horaInicio.date_format' => 'Hora de início inválida',
            'horaFim.date_format' => 'Hora de término inválida',
        ]);


        $DominioService = new DominioService;
        $rowDominio = $DominioService->getById($idDominio);
        $rowDominio = $rowDominio['data'];


        $dadosFiltro = null;
        $dadosFiltro['doutoresId'] = $request->query('doutorId');
        $arrayCamposFiltro = ['dataConsulta' => 'A.data_consulta', 'horaConsulta' => 'A.hora_consulta'];

        if ($validate->fails()) {
            return $this->returnError($validate->errors(), $validate->errors()->all());
        } else {



            //Ordenação
            if ($request->has('orderBy') and ! empty($request->query("orderBy"))) {
                $dadosFiltro['orderBy'] = $this->urlOrderByToFields($arrayCamposFiltro, $request->query("orderBy"));
            }

            //
            if ($request->has('horaInicio') and ! empty($request->query("horaInicio"))) {
                $dadosFiltro['horaInicio'] = $request->query("horaInicio");
            }
            if ($request->has('horaFim') and ! empty($request->query("horaFim"))) {
                $dadosFiltro['horaFim'] = $request->query("horaFim");
            }



            $dadosFiltro['dataInicio'] = $request->query('data');
            $dadosFiltro['dataFim'] = $request->query('dataFim');

            if ($request->has('buscaPaciente') and ! empty($request->query('buscaPaciente'))) {
                $dadosFiltro['buscaPaciente'] = $request->query('buscaPaciente');
            }

            if ($request->has('statusConsulta') and ! empty($request->query('statusConsulta'))) {


                if ($this->validateStatusConsulta($request->query('statusConsulta'))) {
                    $dadosFiltro['statusConsulta'] = $request->query('statusConsulta');
                } else {
                    return $this->returnError(null, ['Um ou mais status da consulta inválidos']);
                }
            }

            if ($request->has('pacienteId') and ! empty($request->query('pacienteId'))) {
                $dadosFiltro['pacienteId'] = trim($request->query('pacienteId'));
            }
            if ($request->has('statusSomenteAgendado') and $request->query('statusSomenteAgendado') == true) {
                $dadosFiltro['statusSomenteAgendado'] = true;
            }

            $dadosPaginacao = $this->getPaginate($request);
            $qrConsultas = $this->consultaRepository->getAll($idDominio, $dadosFiltro, $dadosPaginacao['page'], $dadosPaginacao['perPage']);

            $showProcedimentos = ($request->has('showProcedimentos') and $request->query('showProcedimentos') == 'true') ? true : false;
            $showProntuarios = ($request->has('showProntuarios') and $request->query('showProntuarios') == 'true') ? true : false;


            $retornoResult = [];
            if (count($qrConsultas['results']) > 0) {
                foreach ($qrConsultas['results'] as $chave => $row) {
                    $retornoResult[$chave] = $this->responseFields($row, $rowDominio->dominio, $showProcedimentos, $showProntuarios);
                }
            }

//            var_dump($retornoResult);
            $qrConsultas['results'] = $retornoResult;
            return $this->returnSuccess($qrConsultas);
        }
    }

    /**
     * Retorna as consulta em um array por data e hora  Ex. CONSULTAS[dataCOnsullta][horarios]
     * @param type $idDominio
     * @param type $data
     * @param type $dataFim
     * @param type $doutorId
     */
    public function getAllArrayData($idDominio, $doutorId, $data, $dataFim = null) {

        $dadosFiltro['dataInicio'] = $data;
        $dadosFiltro['dataFim'] = $dataFim;
        $dadosFiltro['doutoresId'] = $doutorId;
        $qrConsultas = $this->consultaRepository->getAll($idDominio, $dadosFiltro);
        $retorno = null;
        if (count($qrConsultas) > 0) {

            $i = 0;
            $horarioAnt = '';
            foreach ($qrConsultas as $row) {
                $horario = substr($row->hora_consulta, 0, 5);
                if ($horario != $horarioAnt) {
                    $i = 0;
                }
                $retorno[$row->data_consulta][$horario][$i] = $row;
                $horarioAnt = substr($row->hora_consulta, 0, 5);
            }
        }

        return $this->returnSuccess($retorno);
    }

    public function getById($idDominio, $consultaId, $dadosFiltro = null) {

        $DominioService = new DominioService;
        $rowDominio = $DominioService->getById($idDominio);
        $rowDominio = $rowDominio['data'];

        $ConsultaRep = new ConsultaRepository;

        $rowConsulta = $ConsultaRep->getById($idDominio, $consultaId);

        $showProcedimentos = (isset($dadosFiltro['showProcedimentos']) and $dadosFiltro['showProcedimentos'] == 'true') ? true : false;
        $showProntuarios = (isset($dadosFiltro['showProntuarios']) and $dadosFiltro['showProntuarios'] == 'true') ? true : false;
        if ($rowConsulta) {
            $retorno = $this->responseFields($rowConsulta, $rowDominio->dominio, $showProcedimentos, $showProntuarios);



            return $this->returnSuccess($retorno);
        } else {
            return $this->returnError(null, 'Consulta não encontrada');
        }
    }

    public function verificaDisponibilidadeConsultasHorario($idDominio, $doutorId, $data, $horario, $verificaConsultaNormal = true, $limiteEncaixe = true) {

        $qrConsultasMarcadas = $this->consultaRepository->getConsultasMarcadasHorario($idDominio, $doutorId, $data, $horario, $verificaConsultaNormal);


        $statusDisponivel = false;


        $rowDefinicoesConsultas = $this->definicaoMarcacaoConsultaRepository->getByDoutoresId($idDominio, $doutorId);

        $limite_consulta = $rowDefinicoesConsultas->limite_consultas;
        if ($limiteEncaixe) {
            $limite_consulta = $rowDefinicoesConsultas->limite_consultas + $rowDefinicoesConsultas->limite_encaixe_consulta;
        }




        $cont = 0;
        $consultaEstendida = false;
        if (count($qrConsultasMarcadas) > 0) {
            foreach ($qrConsultasMarcadas as $row) {

                $idConsulta = $row->id;
                if (!empty($row->hora_consulta_fim) and$row->hora_consulta_fim != '00:00:00') {
                    $consultaEstendida = true;
                }
                $cont++;
                if (!empty($row->statusConsulta) and $row->statusConsulta == 'desmarcado') {
                    $cont--;
                }
            }
        }






        if ($consultaEstendida == false) {

            if ($cont >= $limite_consulta) {
                $statusDisponivel = false;
            } else {
                $statusDisponivel = TRUE;
            }
        } else {
            $statusDisponivel = false;
        }


        return $statusDisponivel;
    }

    public function transferirConsultaDoutor($idDominio, $idBloqueio = null, $consultaId, $doutorId, $data, $hora) {

        $DiasHorariosBloqueadosRepository = new DiasHorariosBloqueadosRepository;

        $campos['doutores_id'] = $doutorId;
        $campos['data_consulta'] = $data;
        $campos['hora_consulta'] = $hora;


        if (!empty($idBloqueio)) {
            $camposHIst['dias_horarios_bloqueados_id'] = $idBloqueio;
        }

        $rowConsultaOrigem = $this->consultaRepository->getById($idDominio, $consultaId);


        if ($rowConsultaOrigem) {

            $camposHIst['consultas_id'] = $consultaId;
            $camposHIst['data_origem'] = $rowConsultaOrigem->data_consulta;
            $camposHIst['hora_origem'] = $rowConsultaOrigem->hora_consulta;
            $camposHIst['doutor_id_origem'] = $rowConsultaOrigem->doutores_id;
            $camposHIst['data_destino'] = $data;
            $camposHIst['hora_destino'] = $hora;
            $camposHIst['doutor_id_destino'] = $doutorId;
            $camposHIst['identificador'] = $idDominio;
            $DiasHorariosBloqueadosRepository->insertHistoricoTransferencia($idDominio, $camposHIst);
        }


        $this->consultaRepository->updateConsulta($idDominio, $consultaId, $campos);
    }

    public function store($idDominio, $dadosInput) {

        $pacienteId = $dadosInput['pacienteId'];
        $doutorId = $dadosInput['doutorId'];
        $data = $dadosInput['data'];
        $horario = $dadosInput['horario'];



        $DominioService = new DominioService;
        $rowDominio = $DominioService->getById($idDominio);
        $rowDominio = $rowDominio['data'];

        $ConsultaReservadaService = new ConsultaReservadaService;
        $HorariosService = new HorariosService;

        $DoutoresService = new DoutoresService();
        $qrDoutor = $DoutoresService->getById($idDominio, $doutorId);

        if (!$qrDoutor['success']) {
            return $this->returnError('', 'Doutor(a) não encontrado');
        }

        $rowDoutor = $qrDoutor['data'];
        if (isset($dadosInput['tipoAtendimento']) and $dadosInput['tipoAtendimento'] == 'video' and ! $rowDoutor['possuiVideoconsulta']) {
            return $this->returnError('', 'Este profissional não aceita consultas por vídeo');
        }

        $PacienteService = new PacienteService();
        $qrPaciente = $PacienteService->getById($idDominio, $pacienteId);

        if (!$qrPaciente['success']) {
            return $this->returnError('', 'Paciente não encontrado');
        }
        $rowPaciente = $qrPaciente['data'][0];

        $qrHorarios = $HorariosService->listHorarios($idDominio, $doutorId, $data, $horario, $data, $horario);

        if (!isset($qrHorarios[0]['horariosList'])) {
            return $this->returnError('', 'Horário indisponível');
        }



        $verficaHorario = false;
        foreach ($qrHorarios[0]['horariosList'] as $rowHorario) {

            if ($horario == $rowHorario['inicio'] and $rowHorario['disponivel'] == true) {
                $verficaHorario = true;
                break;
            }
        }

        if (!$verficaHorario) {
            return $this->returnError('', 'Horário indisponível');
        }




        $camposConsulta['identificador'] = $idDominio;
        $camposConsulta['data'] = Functions::dateDbToBr($data);
        $camposConsulta['data_agendamento'] = time();
        $camposConsulta['data_consulta'] = $data;
        $camposConsulta['hora_consulta'] = $horario;
        $camposConsulta['doutores_id'] = $doutorId;
        $camposConsulta['pacientes_id'] = $pacienteId;

//        $CamposInsert['administrador_id'] = $_SESSION['id_LOGADO'];
//        $CamposInsert['retorno'] = $retorno;
//        $CamposInsert['convenios_id'] = $rowConvenio->convenios_id;
//        $CamposInsert['convenio_numero_carteira'] = $rowConvenio->numero_carteira;
//        $CamposInsert['convenio_validade_carteira'] = $rowConvenio->validade_carteira;
//        $CamposInsert['tipo_desconto'] = $tipo_desconto;
//        $CamposInsert['acrescimo_tipo'] = $tipoAcrescimo;
//        $CamposInsert['confirmacao'] = $confirmacao;




        $idConsulta = $this->consultaRepository->insertConsulta($idDominio, $camposConsulta);
        
        unset($camposConsulta);

//        dd($rowDoutor);
        if ($idConsulta) {

            $linkPagSeguro = null;
            $linkVideo = null;
            $precoConsulta = null;
            

            //Videoconsulta
            if (isset($dadosInput['tipoAtendimento']) and $dadosInput['tipoAtendimento'] == 'video') {
                $precoConsulta = $rowDoutor['precoConsulta'];

                $codVideo = md5($idConsulta);
                $dadosUpdate['codigo_id_videoconf'] = $codVideo;
                $dadosUpdate['videoconferencia'] = 1;
                $dadosUpdate['valor_consulta'] = $precoConsulta;
                $dadosUpdate['room'] = $codVideo;
                $dadosUpdate['room_pass'] = hash('sha256', md5($idConsulta));
                $this->consultaRepository->updateConsulta($idDominio, $idConsulta, $dadosUpdate);

                $linkVideo = $this->getLinkVideo($codVideo, $rowDominio->dominio);

                unset($dadosUpdate);

                    if (isset($dadosInput['linkPagSeguro']) and $dadosInput['linkPagSeguro'] == true) {
                    $PagSeguroItensAPI = new PagSeguroItensAPI;
                    $PagSeguroItensAPI->setItemId('0001');
                    $PagSeguroItensAPI->setItemDescription('Consulta');
                    $PagSeguroItensAPI->setItemAmount($precoConsulta);
                    $PagSeguroItensAPI->setItemQuantity(1);
                    $PagSeguroItensAPI->setItemWeight(1000);

                    $PagSeguroApiService = new PagSeguroApiService;
                  
                    
                    $linkPagSeguro = $PagSeguroApiService->gerarLinkPagamentoConsulta($idDominio, $idConsulta, $rowPaciente->email, $rowDominio->pagseguro_ambiente, $PagSeguroItensAPI);
                    $linkPagSeguro = ($linkPagSeguro) ? $linkPagSeguro['link'] : null;
                }
               
            } else{
//                $precoConsulta = '152';
            }
            
            
      
            

            $StatusRefreshRepository = new StatusRefreshRepository;
            $StatusRefreshRepository->insertAgenda($idDominio, $doutorId);

            if (!empty($rowPaciente->email) and $rowPaciente->envia_email == 1) {
                $EmailAgendamentoService = new EmailAgendamentoService($idDominio);
                $EmailAgendamentoService->setDoutorId($doutorId);
                $EmailAgendamentoService->setNomeDoutor($rowDoutor['nome']);
                $EmailAgendamentoService->setLinkPagseguro($linkPagSeguro);
                $EmailAgendamentoService->setLinkVideo($linkVideo);
                $EmailAgendamentoService->setDataConsulta($data);
                $EmailAgendamentoService->setHoraConsulta($horario);
                $EmailAgendamentoService->setExibelinkConfirmar(true);
                $EmailAgendamentoService->setPrecoConsulta($precoConsulta);
                $EmailAgendamentoService->setEmailPaciente($rowPaciente->email);
                $enviado = $EmailAgendamentoService->sendEmailAgendamento($idDominio, $idConsulta, 'confirmacaoConsulta');
            }


//            $ConsultaReservadaService->store($idDominio, [
//                'consultas_id' => '',
//                'identificador' => $idDominio,
//                'data_expiracao' => date('Y-m-d', strtotime(date('Y-m-d') . " +2 days")),
//            ]);

            return $this->returnSuccess([
                        'consultaId' => $idConsulta
            ]);
        } else {
            return $this->returnError(NULL, 'Ocorreu o erro ao agendar a consulta');
        }
    }

}
