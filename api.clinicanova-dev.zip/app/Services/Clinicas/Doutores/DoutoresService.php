<?php

namespace App\Services\Clinicas\Doutores;

use App\Repositories\Clinicas\DoutoresRepository;
use App\Services\BaseService;
use App\Services\Clinicas\EspecialidadeService;
use App\Services\Clinicas\GrupoAtendimentoService;
use App\Services\Clinicas\IdiomaClinicaService;
use App\Services\Clinicas\DoutorFormacaoService;
use App\Services\Gerenciamento\DominioService;
use App\Services\Clinicas\PacienteService;
use App\Repositories\Clinicas\Doutores\DoutorAvaliacaoRepository;

class DoutoresService extends BaseService {

    private $doutoresRepository;
    private $especialidadeService;
    private $grupoAtendimentoService;
    private $idiomaClinicaService;
    private $doutorFormacaoService;
    private $dominioService;

    public function __construct() {
        $this->doutoresRepository = new DoutoresRepository();
        $this->especialidadeService = new EspecialidadeService();
        $this->grupoAtendimentoService = new GrupoAtendimentoService();
        $this->idiomaClinicaService = new IdiomaClinicaService();
        $this->doutorFormacaoService = new DoutorFormacaoService();
        $this->dominioService = new DominioService();
    }

    public function fieldsResponse($row, $nomeDominio) {

//        dd($row);
        $retorno['id'] = $row->id;
        $retorno['nome'] = $row->nome;
        $retorno['email'] = $row->email;
//        $retorno['telefone'] = $row->telefone;
//        $retorno['celular'] = $row->celular;
//        $retorno['celular2'] = $row->celular2;
        $retorno['sexo'] = $row->sexo;
        $retorno['dataCad'] = $row->dataCad;
        $retorno['possuiVideoconsulta'] = ($row->possui_videoconf == 1) ? true : false;
        $retorno['precoConsulta'] = str_replace(',', '.', str_replace('.', '', $row->preco_consulta));


        if (isset($row->totalConsultasAtendidas)) {
            $retorno['totalConsultasAtendidas'] = $row->totalConsultasAtendidas;
        }

        if (!empty($row->nome_foto)) {
            $retorno['urlFoto'] = env('APP_URL_CLINICAS') . '/' . $nomeDominio . '/arquivos/fotos_doutor/' . $row->nome_foto;
        } else {
            $retorno['urlFoto'] = null;
        }


        $row->possui_videoconf;
//        $retorno['somenteVideoconsulta'] = $row->somente_videoconf;
//        $retorno['idDominio'] = $row->identificador;
//         dd($row->identificador);


        $qrEspecialidades = $this->especialidadeService->getByDoutorId($row->identificador, $row->id);
        if ($qrEspecialidades['success']) {
            $retorno['especialidades'] = $qrEspecialidades['data'];
        } else {
            $retorno['especialidades'] = null;
        }

        $qrGrpAtend = $this->grupoAtendimentoService->getByDoutorId($row->identificador, $row->id);
        if ($qrGrpAtend['success']) {
            $retorno['gruposAtendimento'] = $qrGrpAtend['data'];
        } else {
            $retorno['gruposAtendimento'] = null;
        }

        $qrIdioma = $this->idiomaClinicaService->getByDoutorId($row->identificador, $row->id);

        if ($qrIdioma['success']) {
            $retorno['idiomas'] = $qrIdioma['data'];
        } else {
            $retorno['idiomas'] = null;
        }

        $qrFormacao = $this->doutorFormacaoService->getByDoutorId($row->identificador, $row->id);

        if ($qrFormacao ['success']) {
            $retorno['formacoes'] = $qrFormacao ['data'];
        } else {
            $retorno['formacoes'] = null;
        }

        if (isset($row->tags_tratamentos) and ! empty($row->tags_tratamentos)) {

            $tagsTrat = json_decode($row->tags_tratamentos);

            $retorno['tagsTratamentos'] = $tagsTrat;
        } else {
            $retorno['tagsTratamentos'] = null;
        }


        $retorno['sobre'] = $row->sobre;
        $retorno['pontuacao'] = $row->pontuacao;
        $retorno['perfilId'] = $row->identificador;
        
        $retorno['favoritoPaciente'] = (isset($row->favoritoPaciente) and $row->favoritoPaciente>0)?true:false;

        $retorno['conselho'] = [
            'nome' => (!empty($row->nomeConselhoProfissional)) ? $row->nomeConselhoProfissional : null,
            'sigla' => (!empty($row->codigoConselhoProfisssional)) ? $row->codigoConselhoProfisssional : null,
            'numero' => (!empty($row->conselho_profissional_numero)) ? $row->conselho_profissional_numero : null,
            'uf' => (!empty($row->siglaUFConselhoProfisional)) ? $row->siglaUFConselhoProfisional : null,
            'codCBO' => (!empty($row->codigoCBO)) ? $row->codigoCBO : null,
            'nomeCBO' => (!empty($row->nomeCBO)) ? $row->nomeCBO : null,
        ];

        return $retorno;
    }

    public function getAll($idDominio, $dadosFiltro = null) {



        $filtroOrderBy = null;
        if (isset($dadosFiltro['orderBy']) and ! empty($dadosFiltro['orderBy'])) {
            $arrayOrders = ['nome', 'pontuacao', 'precoConsulta', 'totalConsultasAtendidas', 'dataCad'];
            $orders = explode(',', $dadosFiltro['orderBy']);
            foreach ($orders as $order) {


                if (strpos($order, '.')) {
                    $exOrder = explode('.', $order);
                    if (!in_array($exOrder[0], $arrayOrders) or ( $exOrder[1] != 'asc' and $exOrder[1] != 'desc')) {
                        return $this->returnError('', 'Tipo de ordenação inválida');
                    }

                    $filtroOrderBy[] = $exOrder[0] . ' ' . $exOrder[1];
                } else {

                    if (!in_array($order, $arrayOrders)) {
                        return $this->returnError('', 'Tipo de ordenação inválida');
                    }
                    $filtroOrderBy[] = $order;
                }
            }

            $dadosFiltro['orderBy'] = implode(',', $filtroOrderBy);
        }



        $qr = $this->doutoresRepository->getAll($idDominio, $dadosFiltro);

        if ($qr) {
            $retorno = null;

            $nomesDominio = null;
            foreach ($qr as $chave => $row) {

                if (!isset($nomesDominio[$row->identificador])) {
                    $rowDominio = $this->dominioService->getById($row->identificador);
                    $nomesDominio[$row->identificador] = $rowDominio['data']->dominio;
                }

                $retorno[] = $this->fieldsResponse($row, $nomesDominio[$row->identificador]);
            }

            return $this->returnSuccess($retorno);
        } else {
            return $this->returnError('', 'Nenhum profissional encontrado');
        }
    }

    public function getById($idDominio, $idDoutor) {

        $rowDominio = $this->dominioService->getById($idDominio);
        $rowDominio = $rowDominio['data'];

        $qr = $this->doutoresRepository->getById($idDominio, $idDoutor);

        if ($qr) {
            $retorno = $this->fieldsResponse($qr, $rowDominio->dominio);
            return $this->returnSuccess($retorno);
        } else {
            return $this->returnError('', 'Nenhum profissional encontrado');
        }
    }

    public function storeAvaliacoes($idDominio, $doutorId, $pacienteId, $pontuacao) {


        $qr = $this->doutoresRepository->getById($idDominio, $doutorId);
        if ($qr) {

            $PacienteService = new PacienteService;
            $qrPaciente = $PacienteService->getById($idDominio, $pacienteId);
            if (!$qrPaciente) {
                return $this->returnError('', 'Paciente não encontrado');
            }

            $DoutorAvaliacaoRepository = new DoutorAvaliacaoRepository;
            $DoutorAvaliacaoRepository->store($idDominio, $doutorId, $pacienteId, $pontuacao);


            return $this->returnSuccess('', 'Avaliação realizada com sucesso');
        } else {
            return $this->returnError('', 'Nenhum profissional encontrado');
        }
    }

}
