<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Services\Clinicas\Financeiro;

use App\Services\BaseService;
use DateTime;
use App\Helpers\Functions;
use App\Repositories\Clinicas\Financeiro\RecebimentoRepository;
use App\Repositories\Clinicas\DefinicaoMarcacaoGlobalRepository;
use App\Repositories\Clinicas\Consulta\ConsultaProcedimentoRepository;

/**
 * Description of Activities
 *
 * @author ander
 */
class RecebimentoService extends BaseService {

    private $recebimentoRepository;

    public function __construct() {
        $this->recebimentoRepository = new RecebimentoRepository;
    }

    /**
     * 
     * @param type $idDominio
     * @param type $tipo   Pode ser consulta, orcamento, cateira_virtual
     * @param type $idTipo
     */
    public function getDadosPagamentosEfetuados($idDominio, $tipo, $idTipo) {

        $ConsultaProcedimentoRepository = new ConsultaProcedimentoRepository;

        $DefinicaoMarcacaoGlobalRepository = new DefinicaoMarcacaoGlobalRepository;
        $rowDef = $DefinicaoMarcacaoGlobalRepository->getDadosDefinicao($idDominio);


        $qrRecebimentos = $this->recebimentoRepository->getAllEfetuados($idDominio, $tipo, $idTipo);


        $arrayRecibo = null;

        if (count($qrRecebimentos) > 0) {
            $countRecibo = -1;
            $countDadosReceb = 0;
            $codTipoAnt = '';

//            $OrcamentoItens = new OrcamentosItens();
//            $Consulta = new Consultas();

            foreach ($qrRecebimentos as $rowReceb) {

                if ($tipo == 'orcamento') {
//                    $codTipo = 'orc_' . $rowReceb->orcamentos_id . '_' . $rowReceb->idsProcParcial;
//                    if (!empty($rowReceb->idsProcParcial)) {
//                        $procedimentos = $OrcamentoItens->getByIdsItens($identificador, $rowReceb->orcamentos_id, $rowReceb->idsProcParcial);
//                    } else {
//                        $procedimentos = $OrcamentoItens->getAll($identificador, $rowReceb->orcamentos_id);
//                    }
                } else if ($tipo == 'consulta') {
                    $codTipo = 'consul_' . $rowReceb->consulta_id . '_' . $rowReceb->idsProcParcial;

                    if (!empty($rowReceb->idsProcParcial)) {

                        $procedimentos = $ConsultaProcedimentoRepository->getByConsultaId($idDominio, $rowReceb->consulta_id, explode(',', $rowReceb->idsProcParcial));
                    } else {
                        $procedimentos = $ConsultaProcedimentoRepository->getByConsultaId($idDominio, $rowReceb->consulta_id);
                    }
                } else if ($tipo == 'carteira_virtual') {
//                    $CarteiraVirtual = new CarteiraVirtual();
//                    $codTipo = 'cart_virt_' . $rowReceb->carteira_virtual_id . '_' . $rowReceb->idsProcParcial;
//                    $rowCarteira = $CarteiraVirtual->getById($identificador, $rowReceb->carteira_virtual_id);
//                    $procClass = new stdClass();
//                    $procClass->nome_proc = $rowCarteira->nome_pacote;
//                    $procClass->qnt = 1;
//                    $procClass->valorProc = $rowCarteira->valor_proc;
//                    $procedimentos[0] = $procClass;
//                if (!empty($rowReceb->idsProcParcial)) {
//                    $procedimentos = $OrcamentoItens->getByIdsItens($identificador, $rowReceb->orcamentos_id, $rowReceb->idsProcParcial);
//                } else {
//                    $procedimentos = $OrcamentoItens->getAll($identificador, $rowReceb->orcamentos_id);
//                }
                }
//
//

               
                if (isset($arrayIndice[$codTipo])) {
                    $indice = $arrayIndice[$codTipo];
                } else {
                    $countRecibo++;
                    $countDadosReceb = 0;
                    $indice = $countRecibo;
                    $arrayIndice[$codTipo] = $countRecibo;
                }
                if ($codTipo != $codTipoAnt) {
                    $procI = 0;
                    
                    foreach ($procedimentos as $rowProc) {
                        $ProcedimentosA[$procI]['idProcItem'] = $rowProc->id;   //chave primaria das tabelas consulta_procedimentos ou orcamentos_proc_itens
                        $ProcedimentosA[$procI]['nome'] = $rowProc->nome_proc;
                        $ProcedimentosA[$procI]['procedimentoId'] = $rowProc->procedimentos_id;
                        $ProcedimentosA[$procI]['qnt'] = $rowProc->qnt;
                        $ProcedimentosA[$procI]['valorProc'] = $rowProc->valor_proc;
                        $ProcedimentosA[$procI]['nomeConvenio'] = $rowProc->nome_convenio;
                        $ProcedimentosA[$procI]['idConvenio'] = $rowProc->convenios_id;
                        $ProcedimentosA[$procI]['nomeCategoria'] = $rowProc->procedimentos_cat_nome;
                        $ProcedimentosA[$procI]['pagParcial'] = $rowProc->pag_parcial;
                        $ProcedimentosA[$procI]['idCarteiraItem'] = $rowProc->id_carteira_item;
                        $ProcedimentosA[$procI]['financeiroRecebimentosId'] = $rowProc->financeiro_recebimentos_id;
                        $ProcedimentosA[$procI]['codCarteiraVirtual'] = $rowProc->codCarteiraVirtual;
                        $ProcedimentosA[$procI]['nomePacote'] = $rowProc->nome_pacote;
                        $ProcedimentosA[$procI]['tipoRepasse'] = $rowProc->tipo_repasse;
                        $ProcedimentosA[$procI]['percentualRepasse'] = $rowProc->percentual_proc_repasse;
                        $ProcedimentosA[$procI]['valorRepasse'] = $rowProc->valor_repasse;
                        $ProcedimentosA[$procI]['percentImpostoRendaConvenio'] = $rowProc->imposto_renda_convenio;
                        $ProcedimentosA[$procI]['valorLiquidoProc'] = (empty($rowProc->nome_pacote)) ? $rowProc->valor_liquido_proc : 0;
                        $ProcedimentosA[$procI]['aliquotaIss'] = $rowProc->aliquota_iss;
                        $ProcedimentosA[$procI]['aliquotaIssPercentual'] = $rowProc->aliquota_iss_percentual;
                        $ProcedimentosA[$procI]['baseCalcPacoteItem'] = $rowProc->base_calc_pacote_item;
                        $ProcedimentosA[$procI]['exibirAppNeofor'] = $rowProc->exibir_app_docbizz;
                        $procI++;
                    }
                    $arrayRecibo[$indice]['procedimentos'] = $ProcedimentosA;
                }



                $taxa = null;
                if (!empty($rowReceb->possui_tp_pag_taxa)) {
                    $taxa['removida'] = ($rowReceb->possui_tp_pag_taxa == 2) ? true : false;
                    $taxa['percentual'] = $rowReceb->percentual_pag_taxa;
                    $taxa['valor'] = $rowReceb->valor_tp_pag_taxa;
                }
//
                $dadosReceb['codigoRecebimento'] = Functions::codFinanceiroRecDesp($rowDef->tipo_cod_fin, $rowReceb->ano_codigo, $rowReceb->rec_codigo);
                $dadosReceb['tipo_pag_nome'] = $rowReceb->tipo_pag_nome;
                $dadosReceb['pago'] = ($rowReceb->pago) ? 'Sim' : 'Não';
                $dadosReceb['periodoNome'] = $rowReceb->periodoNome;
                $dadosReceb['parcelas'] = ($rowReceb->periodo_repeticao_id != 1) ? $rowReceb->quantidade_parcelas : '';
                $dadosReceb['id_recebimento'] = $rowReceb->idRecebimento;
                $dadosReceb['taxa'] = $taxa;
                $dadosReceb['valor_total'] = $rowReceb->totalParcelado;



//
                $arrayRecibo[$indice]['dadosRecebimento'][$countDadosReceb] = $dadosReceb;
                $arrayRecibo[$indice]['idsRecebimento'][] = $rowReceb->idRecebimento;
                $arrayRecibo[$indice]['fornecedor_nome'] = $rowReceb->fornecedor_nome;
                $arrayRecibo[$indice]['categoria_nome'] = $rowReceb->categoria_nome;
                $arrayRecibo[$indice]['recebimento_data_vencimento'] = $rowReceb->recebimento_data_vencimento;
                $arrayRecibo[$indice]['recebimento_data'] = $rowReceb->recebimento_data;
                $arrayRecibo[$indice]['dt_pagamento'] = $rowReceb->recebimento_data;
                $arrayRecibo[$indice]['valor_bruto'] = $rowReceb->valor_total_procedimento;
                $arrayRecibo[$indice]['valor_desconto'] = $rowReceb->valor_desconto;
                $arrayRecibo[$indice]['tipo_acrescimo'] = $rowReceb->acrescimo_tipo;
                $arrayRecibo[$indice]['percentual_acrescimo'] = $rowReceb->acrescimo_percentual;
                $arrayRecibo[$indice]['valor_acrescimo'] = $rowReceb->acrescimo_valor;
                $arrayRecibo[$indice]['valor_liquido'] = $rowReceb->total_recebimento;
                $arrayRecibo[$indice]['descricao'] = $rowReceb->recebimento_descricao;
                $arrayRecibo[$indice]['codigoRecebimento'] = Functions::codFinanceiroRecDesp($rowDef->tipo_cod_fin, $rowReceb->ano_codigo, $rowReceb->rec_codigo);
                $arrayRecibo[$indice]['dt_vencimento'] = $rowReceb->recebimento_data_vencimento;

                $countDadosReceb++;
                unset($dadosReceb);

                $codTipoAnt = $rowReceb->orcamentos_id . '_' . $rowReceb->idsProcParcial;
                unset($ProcedimentosA);
            }
        }
        return $arrayRecibo;
    }

}
